// Sean Jones
// 02-10-2023
// CS 210 Programming Languages
// Bill Chan

#include <iostream> // allows use of input and output
#include <iomanip>

using namespace std;

int main()
{
    float initialInvestment, monthlyDeposit, annualInterest, numMonths, numYears; // declaration of variables for input
    float yearEndTotal, interest, yearEndInterest; // variables to store interest calculation numbers

    // outputs menu and allows user to input data
    cout << "******************************\n";
    cout << "********* Data Input *********\n";
    cout << "Initial Investment Amount: $";
    cin >> initialInvestment;
    cout << "Monthly Deposit: $";
    cin >> monthlyDeposit;
    cout << "Annual Interest: %";
    cin >> annualInterest;
    cout << "Number of years: ";
    cin >> numYears;
    numMonths = numYears * 12;

    system("PAUSE"); // this puts out "Press any key to continue..." and waits for user input

    yearEndTotal = initialInvestment;

    // this displays the year data without any monthly deposits from user
    cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
    cout << "==============================================================\n";
    cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
    cout << "--------------------------------------------------------------\n";


    for (int i = 0; i < numYears; i++)
    {

        // this calculates the yearly interest rate
        interest = (yearEndTotal) * ((annualInterest / 100));

        // this calculates the year end total for user
        yearEndTotal = yearEndTotal + interest;

        // this prints the results
        cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << yearEndTotal << "\t\t\t$" << interest << "\n";

    }

    yearEndTotal = initialInvestment;

    // this displays the year data with continuous monthly deposits by the user
    cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
    cout << "==============================================================\n";
    cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
    cout << "--------------------------------------------------------------\n";

    for (int i = 0; i < numYears; i++)
    {

        yearEndInterest = 0;

        for (int j = 0; j < 12; j++)
        {

            // this calculates the monthly interest
            interest = (yearEndTotal + monthlyDeposit) * ((annualInterest / 100) / 12);

            // this calculates the end interest
            yearEndInterest = yearEndInterest + interest;

            // this calculates the end total
            yearEndTotal = yearEndTotal + monthlyDeposit + interest;

        }

        // this prints the results
        cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << yearEndTotal << "\t\t\t$" << yearEndInterest << "\n";


    }

    return 0;
}